# Knock (to Unlock) Puppet Module for Boxen

## Usage

```puppet
include knock
```

## Required Puppet Modules

* boxen

## Developing

Write code.

Run `script/cibuild`.
